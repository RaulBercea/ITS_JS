# 03 Baby Processing

## Author Details

-   Name : Raul
-   Surname: Bercea
-   Mail: raul.bercea@edu.itspiemonte.it

## Excercise Requirements

Using the babies array from the previous exercise:

-   Write a getBabyOutfit() function that returns a description a baby's outfit
    -   e.g "Lyla is wearing a blue shirt and red pants and a green hat"
-   Write a feedBaby() function that prints what a baby is eating
    -   e.g. "Lyla is eating food3, food1, food4 and food2"
    -   All foods in favoriteFoods should appear but randomly each time the function is called
-   Run both function on all the babies

## Aproach to Solution

by using for ... in loop i can access all of the proprieties of the
each object and manipulate it. in this case getting all of the outfits
and favorite foods of the babies and forming sentences based on each of
them
