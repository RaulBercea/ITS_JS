# 01 Story

## Author Details

- Name : Raul
- Surname: Bercea
- Mail: raul.bercea@edu.itspiemonte.it

## Excercise Requirements

- Given the following array

```javascript
let noisesArray = ["quack", "sneeze", "boom"];
```

Produce the following array, then print it to the console

```javascript
['Quack!','qUack!!','quAck!!!','quaCk!!!!','quacK!!!!!','Sneeze!','sNeeze!!','snEeze!!!','sneEze!!!!
','sneeZe!!!!!','sneezE!!!!!!','Boom!','bOom!!','boOm!!!','booM!!!!']
```

## aproach to solution

By using a for each loop to target the array of strings i can use a classic for loop to target all of the character within each string then by using string and array methods(like split and join) i can modify the characters one by one.