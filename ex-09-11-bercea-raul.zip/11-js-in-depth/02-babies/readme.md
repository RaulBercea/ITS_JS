# 02 Babies

## Author Details

-   Name : Raul
-   Surname: Bercea
-   Mail: raul.bercea@edu.itspiemonte.it

## Excercise Requirements

-   Create an empty array of babies
-   Each baby should have the following properties
    -   "name" (a string)
    -   "months" (age in months as number)
    -   "noises" (an array of strings)
    -   "favoriteFoods" (an array of strings)
-   Add 4 different babies to the array using as many different ways as possible
-   Iterate through the array printing key and value pairs e.g [name: Lyla]
-   Now add an "outfit" property to each baby in the array
    -   Outfit should describes at least 3 parts of their clothing using different properties, for example, "shirt": "blue"
    -   Print each baby again with their outfit in a nicely formatted object

## Aproach to Solution

By using push,unshif,the length of the array and the splice method i've
added four objects to the array after that i've added a random color to
three parts of the outfit of the baby in order to output to the console
in a properly formatted manner i've used a for in nested inside another
for in to print any nested objects and the proprieties of the objects
themselves
