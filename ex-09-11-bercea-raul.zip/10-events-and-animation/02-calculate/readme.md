# 01 Calculate

## Author Details

-   Name : Raul
-   Surname: Bercea
-   Mail: raul.bercea@itspiemonte.it

## Excercise Requirements

-   Add inputs for half number, percentage and circle area
-   Use the functions from the previous calculator exercises
-   For each operation, create an event listener for the button, and when it's clicked, find the value of the appropriate input and show the result of the calculation in the solution div
-   Afterwards, change the code so that you respond to key presses so that the user doesn't have to click the button

## Aproach to Solution

By using the event listeners in javascript and and by getting the
value of an input i can call functions based on the action an user
makes. In this case the event listeners first target the click of
the buttons to call the functions, while in the second case the
event listener used is the "keyup" event listener wich triggers
after the user has typed when the key has been released
