# 01 Story

## Author Details

-   Name : Raul
-   Surname: Bercea
-   Mail: raul.bercea@edu.itspiemonte.it

## Excercise Requirements

-   Add an event listener to the button so that it calls a makeStory function when clicked.
-   In the makeStory function, retrieve the current values of the form input elements, make a story from them, and output that in the story div (like "Joseph really likes pink cucumbers.")

## Aproach to Solution

By using an event listener targetting the button in the page I've called a function wich changes the text content of the div with the "story" id.
When the button is pressed the function getts called and reads the values of the input fields and writes them on the page within the div
