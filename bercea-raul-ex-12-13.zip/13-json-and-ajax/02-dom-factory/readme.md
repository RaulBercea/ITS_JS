## 02 Dom Factory

## Author Details

-   Name : Raul
-   Surname: Bercea
-   Mail: raul.bercea@edu.itspiemonte.it

## Excercise requirements

-   Write your cars and factory objects as JSON strings in a variable.
-   Parse them with JSON.parse();
-   Write each of them to the DOM in a list
    -   You should use a CSS styled <ul><li> list with no bullets
    -   Don’t use <table>

## Aproach to solution

in order to add a JSON file it needs to be parsed first, then by using the document methods in javascript and by checking what type of data is stored in the json(in this case arrays, objects or strings) manipulating them acordingly and then adding them to the dom by making different nodes for the key of the json and the values stored inside it
